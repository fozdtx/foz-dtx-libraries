class Vector_2{
	public:
		int x;
		int y;
};

Vector_2 vector2;

class Vector_3{
	public:
	int x;
	int y;
	int z;
};

Vector_3 vector3;

int Vector2(int x, int y){
	vector2.x = x;
	vector2.y = y;
}

int Vector3(int x, int y, int z){
	vector3.x = x;
	vector3.y = y;
	vector3.z = z;
}
